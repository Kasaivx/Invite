const joinServerLink = document.querySelector('#join-server-container a');
const downloadMinecraftLink = document.getElementById('download-minecraft');
const confirmationMessage = document.getElementById('confirmation-message');


function showConfirmationMessage(event) {
    event.preventDefault(); 
    confirmationMessage.style.display = 'block';
    setTimeout(() => {
        confirmationMessage.style.display = 'none';
    }, 2000);


    setTimeout(() => {
        window.location.href = event.target.href;
    }, 800);
}

joinServerLink.addEventListener('click', showConfirmationMessage);
downloadMinecraftLink.addEventListener('click', showConfirmationMessage);

audio.volume = 0.4;